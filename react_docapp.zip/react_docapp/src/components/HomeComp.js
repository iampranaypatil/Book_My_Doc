import image5 from'../images/image5.jpg';



export default function HomeComp(){

    return (
		<div>	

			<div className='image'>
				<img className="" src={image5} alt="Hospital" width="100%"></img>
				
			</div>
			
			</div>
    )
}