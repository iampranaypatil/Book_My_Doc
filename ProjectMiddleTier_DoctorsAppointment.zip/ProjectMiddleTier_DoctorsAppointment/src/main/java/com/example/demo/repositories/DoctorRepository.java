package com.example.demo.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Doctor;
import com.example.demo.entities.Login;
import com.example.demo.entities.User;

import jakarta.transaction.Transactional;

@Transactional
@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Integer> {

	@Query("select d from Doctor d where user_id = :user_id")
	public Doctor getDoctorByUId(User user_id);
	
	@Query("select d from Doctor d where doctor_id = :did")
	public Doctor getDoctorByDId(int did);
	
	@Query("select distinct d.department from Doctor d")
	public List<String> getDepartments();
	
	@Query("select d from Doctor d where department = :dept")
	public List<Doctor> getDoctorsByDept(String dept);

	@Modifying
	@Query("update Doctor set image = :image where doctor_id = :doctor_id")
	public int saveImage(int doctor_id,byte [] image);

}
