package com.example.demo.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Login;
import com.example.demo.entities.QuestionAnswer;
import com.example.demo.entities.Questions;
import com.example.demo.entities.User;

import jakarta.transaction.Transactional;

@Transactional
@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

	@Query("select u from User u where email= :email and password= :password")
	public Optional<User> getLogin(String email,String password);
	
	@Query("select question_id from User u where email = :email")
	public Questions getQuestion(String email);
	
	@Query("select answer from User u where email = :email")
	public String getAnswer(String email);
	
	@Modifying
	@Query("update User set password = :pwd where email = :email")
	public int changePassword(String email,String pwd);
}
