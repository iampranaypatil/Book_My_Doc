package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Appointment;
import com.example.demo.entities.AppointmentStatus;
import com.example.demo.entities.Doctor;
import com.example.demo.entities.Patient;
import com.example.demo.entities.Role;

import jakarta.transaction.Transactional;

@Transactional
@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {
	
	
	@Query("Select a from Appointment a where doctor_id = :did and status_id = 1")
	public List<Appointment> getAppointmentsofDoctor(Doctor did);
	
	@Query("Select a from Appointment a where patient_id = :pid ")
	public List<Appointment> getAppointmentsofPatient(Patient pid);
	
	// This method is from patient service
	@Modifying
	@Query("update Appointment set status_id= :as where app_id = :aid")
	public int appointmentCancellationRequest(int aid,AppointmentStatus as);
	
	@Query("Select a from Appointment a where status_id= :as")
	public List<Appointment> cancellationRequestedAppointments(AppointmentStatus as);
	
	@Modifying
	@Query("update Appointment set status_id= :as where app_id = :aid")
	public int approveAppointmentCancellation(int aid,AppointmentStatus as);
}
